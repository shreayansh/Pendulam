import java.io.*;
import java.util.*;

public class Solution {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t=sc.nextInt();
        int i=0;
        while (i<t)
        {
            i++;
            int n=sc.nextInt();
            int[] arr=new int[n];
            for (int j = 0; j < n; j++) {
                arr[j]=sc.nextInt();
            }
            Arrays.sort(arr);
            int[] arr1=new int[n];
            int k=n/2;
            arr1[k]=arr[0];
            for (int j = 1; j < n; j=j+2) {
                k++;
                arr1[k]=arr[j];

            }
            k=-1;
            for (int j = n-1; j >=2; j=j-2) {
                k++;
                arr1[k]=arr[j];

            }
            System.out.println(Arrays.toString(arr1));



        }
    }
}
